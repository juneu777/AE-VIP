// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VESC_MSGS__MSG__VESC_IMU_HPP_
#define VESC_MSGS__MSG__VESC_IMU_HPP_

#include "vesc_msgs/msg/detail/vesc_imu__struct.hpp"
#include "vesc_msgs/msg/detail/vesc_imu__builder.hpp"
#include "vesc_msgs/msg/detail/vesc_imu__traits.hpp"

#endif  // VESC_MSGS__MSG__VESC_IMU_HPP_
