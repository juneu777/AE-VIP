// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VESC_MSGS__MSG__VESC_IMU_STAMPED_HPP_
#define VESC_MSGS__MSG__VESC_IMU_STAMPED_HPP_

#include "vesc_msgs/msg/detail/vesc_imu_stamped__struct.hpp"
#include "vesc_msgs/msg/detail/vesc_imu_stamped__builder.hpp"
#include "vesc_msgs/msg/detail/vesc_imu_stamped__traits.hpp"

#endif  // VESC_MSGS__MSG__VESC_IMU_STAMPED_HPP_
