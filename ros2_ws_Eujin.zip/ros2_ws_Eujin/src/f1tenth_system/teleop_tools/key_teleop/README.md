key_teleop
==========

A text-based interface to send a ROS-powered robot movement commands
