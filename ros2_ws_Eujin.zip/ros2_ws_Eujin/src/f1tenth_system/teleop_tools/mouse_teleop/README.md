mouse_teleop
============

A pointing device (e.g. mouse, touchpad) teleop tool for mobile robots,
supporting holonomic and differential drive platforms.
