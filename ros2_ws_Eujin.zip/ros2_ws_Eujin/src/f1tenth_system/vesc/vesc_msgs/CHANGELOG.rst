^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package vesc_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.0 (2020-12-12)
------------------
* Merge pull request `#1 <https://github.com/f1tenth/vesc/issues/1>`_ from f1tenth/melodic-devel
  Updating for Melodic
* Updating package.xml to format 3 and setting C++ standard to 11.
* Contributors: Joshua Whitley

1.0.0 (2020-12-02)
------------------
* Adding roslint.
* Updating maintainers, authors, and URLs.
* added onboard car
* Contributors: Joshua Whitley, billyzheng
